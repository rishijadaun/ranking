<?php get_header(); ?>
<section class="pagecontent">
	<?php
	if ( have_posts() ) :
	  while ( have_posts() ) : the_post(); ?>
	  	<div class="ranking_page_banner">
	  	   <div class="container">
	        <h1 class="text-white display-2"><?php the_title() ?></h1>
	       </div>
	    </div>
	    <div class="container pb-5 pt-5">
	    <?php the_content() ?>
	   </div>
	  <?php endwhile;
	else :
	  echo '<p>There are no posts!</p>';
	endif;
	?> 
</section>
<?php get_footer(); ?>