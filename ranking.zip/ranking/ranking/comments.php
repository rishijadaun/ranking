<div>
    <?php /* Add conditional checks, styling and arguments here... */ ?>
    <?php wp_list_comments(); 
		paginate_comments_links( array(
		    'prev_text'  => 'back',
		    'next_text' => 'forward'
		) );
    ?>
</div>
