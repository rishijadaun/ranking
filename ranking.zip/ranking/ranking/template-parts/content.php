<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">

<?php
			if ( is_search() || ! is_singular() && 'summary' === get_theme_mod( 'blog_content', 'full' ) ) {
				the_excerpt();
			} else {
				the_content( __( 'Continue reading', 'ranking' ) );
			}
			?>

</article><!-- .post -->
