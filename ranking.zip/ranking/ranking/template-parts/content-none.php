<article class="no-results">

  <header class="entry-header">
    <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'ranking' ); ?></h1>
  </header>
  <div class="entry-content">
    <p><?php esc_html_e( 'It looks like nothing was found at this location.', 'ranking' ); ?></p>
  </div>

</article>