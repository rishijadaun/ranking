<?php get_header(); ?>
<section class="searchpage pb-5 pt-5">
  <div class="site-content container">
	  <header class="page-header">
		  <h1 class="page-title display-4">
			  <?php
				  /* translators: %s: the search query */
				  printf( esc_html__( 'Search Results for: %s', 'ranking' ), '<span>' . get_search_query() . '</span>' );
			  ?>
		  </h1>
	  </header><!-- .page-header -->
	  <hr>
	    <?php
	    if ( have_posts() ) :

	      while ( have_posts() ) :

	        the_post();
	        ?>

	        <article <?php post_class(); ?>>

	          <header class="entry-header">
	            <?php the_title( '<h2 class="entry-title display-6">', '</h2>' ); ?>
	          </header><!-- .entry-header -->

	          <div class="entry-content">
	            <?php the_content( esc_html__( 'Continue reading &rarr;', 'ranking' ) ); ?>
	          </div><!-- .entry-content -->

	        </article><!-- #post-## -->

	        <?php
	        // If comments are open or we have at least one comment, load up the comment template.
	        if ( comments_open() || get_comments_number() ) :
	          comments_template();
	        endif;

	      endwhile;

		  the_posts_navigation();

	    else :
	      get_template_part( 'content-none' );
	      echo "No Result found!";
	    endif;
		?>
	</div><!-- .site-content -->
</section>
<?php
get_footer();