<?php 
if ( ! function_exists( 'rankwptheme_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function rankwptheme_setup() {
 
    /**
     * Make theme available for translation.
     * Translations can be placed in the /languages/ directory.
     */
    load_theme_textdomain( 'ranking', get_template_directory() . '/languages' );
 
    /**
     * Add default posts and comments RSS feed links to <head>.
     */
    add_theme_support( 'automatic-feed-links' );

    add_theme_support( 'custom-header' );
        $defaults = array(
        'default-color'          => 'ffffff',
        'default-image'          => '',
        'default-repeat'         => 'repeat',
        'default-position-x'     => 'left',
            'default-position-y'     => 'top',
            'default-size'           => 'auto',
        'default-attachment'     => 'scroll',
        'wp-head-callback'       => '_custom_background_cb',
        'admin-head-callback'    => '',
        'admin-preview-callback' => ''
    );
    // add_theme_support( 'custom-background', $defaults );
    add_theme_support( 'custom-background', apply_filters( 'custom_background_args', array(
            'default-color' => '#ffffff',
            'default-image' => '',
    ) ) );
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    set_post_thumbnail_size( 1200, 9999 );
    add_image_size( 'ranking-custom-image-size', 830, 400 );
    add_image_size( 'ranking-post-image-size', 350, 250 );
    /**
     * Enable support for post thumbnails and featured images.
     */
    add_theme_support( 'post-thumbnails' );
 
    /**
     * Add support for two custom navigation menus.
     */
    // This theme uses wp_nav_menu() in one location.
        register_nav_menus( array(
            'primary' => esc_html__( 'Primary', 'ranking' ),
        ) );
     // Support editor style.
        add_editor_style( array( 'style.css' ) );
    /**
     * Enable support for the following post formats:
     * aside, gallery, quote, image, and video
     */
    add_theme_support( 'post-formats', array( 'aside', 'image', 'gallery', 'video', 'audio', 'quote', 'link' ) );
    // Gutenberg.
        add_theme_support( 'editor-styles' );
        add_theme_support( 'align-wide' );
        add_theme_support( 'wp-block-styles' );
        add_theme_support( 'responsive-embeds' );
}
endif; // myfirsttheme_setup
add_action( 'after_setup_theme', 'rankwptheme_setup' );


function rankwptheme_widgets_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer First', 'ranking' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'ranking' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
    register_sidebar(
        array(
            'name'          => esc_html__( 'Footer Second', 'ranking' ),
            'id'            => 'sidebar-2',
            'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'ranking' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__( 'Footer Third', 'ranking' ),
            'id'            => 'sidebar-3',
            'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'ranking' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__( 'Footer Fourth', 'ranking' ),
            'id'            => 'sidebar-4',
            'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'ranking' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
     register_sidebar(
        array(
            'name'          => esc_html__( 'Blog Sidebar', 'ranking' ),
            'id'            => 'sidebar-blog',
            'description'   => esc_html__( 'Add widgets here to appear in your blog.', 'ranking' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action( 'widgets_init', 'rankwptheme_widgets_init' );


function rankwptheme_enqueue_style() {
    wp_enqueue_style( 'bts-css',  get_template_directory_uri() .'/assets/css/bootstrap.min.css', false );
    wp_enqueue_style( 'ranking-css',  get_template_directory_uri() .'/assets/css/ranking-style.css', false );
}
 
function rankwptheme_enqueue_script() {
    wp_enqueue_script( 'bts-js', get_template_directory_uri() .'/assets/js/bootstrap.bundle.min.js', false );
}
 
add_action( 'wp_enqueue_scripts', 'rankwptheme_enqueue_style' );
add_action( 'wp_enqueue_scripts', 'rankwptheme_enqueue_script' );

function add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_link_atts');


if ( ! function_exists( 'wp_body_open' ) ) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}



