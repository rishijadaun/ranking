<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name='viewport' content='width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no'>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <meta name="theme-color" content="#7952b3">
        <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
        <?php wp_head(); ?>
    </head>
<body <?php body_class(); ?>>
	<?php // get_template_part( '/header/top' ); ?>
    <header class="mainheader">
	   <nav class="navbar navbar-expand-lg navbar-light bg-light">
	   <div class="container-fluid">
	    <span class="navbar-brand"><?php the_custom_logo(); ?></span>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    	<?php
						if ( has_nav_menu( 'primary' ) ) {
							?>
								<ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-auto">
									<?php
									if ( has_nav_menu( 'primary' ) ) {

										wp_nav_menu(
											array(
												'container'  => '',
												'items_wrap' => '%3$s',
												'theme_location' => 'primary',
											)
										);

									}
									?>
								</ul>
							<!-- .primary-menu-wrapper -->
							<?php
						}
						?>
	    <?php // wp_nav_menu( array( 'theme_location' => 'header-menu','menu_class' => "navbar-nav me-auto mb-2 mb-lg-0", 'menu_id'        => 'header-menu', ) ); 

			// wp_nav_menu(  array(
			//     'menu'              => "Header Menu", // (int|string|WP_Term) Desired menu. Accepts a menu ID, slug, name, or object.
			//     'menu_class'        => "HeaderMenu", // (string) CSS class to use for the ul element which forms the menu. Default 'menu'.
			//     'menu_id'           => "HeaderMenu", // (string) The ID that is applied to the ul element which forms the menu. Default is the menu slug, incremented.
			//     'container'         => "", // (string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
			//     'container_class'   => "", // (string) Class that is applied to the container. Default 'menu-{menu slug}-container'.
			//     'container_id'      => "", // (string) The ID that is applied to the container.
			//     'fallback_cb'       => "", // (callable|bool) If the menu doesn't exists, a callback function will fire. Default is 'wp_page_menu'. Set to false for no fallback.
			//     'before'            => "", // (string) Text before the link markup.
			//     'after'             => "", // (string) Text after the link markup.
			//     'link_before'       => "", // (string) Text before the link text.
			//     'link_after'        => "", // (string) Text after the link text.
			//     'echo'              => "", // (bool) Whether to echo the menu or return it. Default true.
			//     'depth'             => "", // (int) How many levels of the hierarchy are to be included. 0 means all. Default 0.
			//     'walker'            => "", // (object) Instance of a custom walker class.
			//     'theme_location'    => "header-menu", // (string) Theme location to be used. Must be registered with register_nav_menu() in order to be selectable by the user.
			//     'items_wrap'        => "", // (string) How the list items should be wrapped. Default is a ul with an id and class. Uses printf() format with numbered placeholders.
			//     'item_spacing'      => "", // (string) Whether to preserve whitespace within the menu's HTML. Accepts 'preserve' or 'discard'. Default 'preserve'.
			// ) );

	    ?> 	 
	    <?php // get_search_form();  ?>
	    </div>
	  </div>
	</nav>
    </header>
<main class="mainblog">
<!-- <div class="blog-header">
  <h1 class="blog-title"><a href="<?php // echo get_bloginfo( 'wpurl' );?>"><?php // echo get_bloginfo( 'name' ); ?></a></h1>
  <p class="lead blog-description"><a href="<?php // echo esc_url( home_url( '/' ) ); ?>"><?php // echo get_bloginfo( 'description' ); ?></a></p>
</div> -->
