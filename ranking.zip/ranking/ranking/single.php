<?php get_header(); ?>
<section class="singlepage pb-5 pt-5">
	<div class="container">
	<div class="row">
		<div class="col-md-9">
			<div class="site-content">
				 <?php // echo $key_1_value = get_post_meta( get_the_ID(), 'origin', true ); ?>
				<?php
				$format = get_post_format() ? : 'standard';
				if ( have_posts() && $format && is_singular()) :
				
					while ( have_posts() ) :
						the_post();
						?>
						<article <?php post_class(); ?>>
						    <?php if(has_post_thumbnail()) the_post_thumbnail( 'ranking-custom-image-size' ); ?>
						<div class="ranking-post-info p-2">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-check" viewBox="0 0 16 16">
						  <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
						  <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
						</svg> <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
						<?php $categories = get_the_category();
						$separator = ' ';
						$output = '';
						if ( ! empty( $categories ) ) {
						    foreach( $categories as $category ) {
						        $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bookmarks" viewBox="0 0 16 16">
				  <path d="M2 4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v11.5a.5.5 0 0 1-.777.416L7 13.101l-4.223 2.815A.5.5 0 0 1 2 15.5V4zm2-1a1 1 0 0 0-1 1v10.566l3.723-2.482a.5.5 0 0 1 .554 0L11 14.566V4a1 1 0 0 0-1-1H4z"/>
				  <path d="M4.268 1H12a1 1 0 0 1 1 1v11.768l.223.148A.5.5 0 0 0 14 13.5V2a2 2 0 0 0-2-2H6a2 2 0 0 0-1.732 1z"/>
				</svg> <a href="' . esc_url( get_category_link( $category->term_id ) ) . '" title="' . esc_attr( sprintf( __( 'View all posts in %s', 'ranking' ), $category->name ) ) . '">' . esc_html( $category->name ) . '</a>' . $separator;
						    }
						    echo trim( $output, $separator );
						} ?>
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
						  <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
						  <path fill-rule="evenodd" d="M15.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L12.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
						</svg> <?php $author_id = get_the_author_meta( 'ID' );
                        ?>

                        <?php 
                        echo '<a href="' . esc_url( get_the_author_meta( 'user_url', $author_id ) ) . '" title="' . esc_attr( sprintf( __( 'View all posts in %s author', 'ranking' ), get_the_author_meta( 'display_name', $author_id ) ) ) . '">' . esc_html( get_the_author_meta( 'display_name', $author_id ) ) . '</a>';
						 ?>
					</div>
							<header class="entry-header">
								<?php the_title( '<h1 class="entry-title display-4">', '</h1>' ); ?>
							</header>

							<div class="entry-content">
								<?php the_content( esc_html__( 'Continue reading &rarr;', 'ranking' ) ); ?>
							</div>
						 <?php

							wp_link_pages(
								array(
									'before' => '<div class="page-links">' . __( 'Pages:', 'ranking' ),
									'after'  => '</div>',
								)
							);
						?>
						</article>
						<div class="pagination">
						<?php the_post_navigation(
							array(
								'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'ranking' ) . '</span> <span class="nav-title">%title</span>',
								'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'ranking' ) . '</span> <span class="nav-title">%title</span>',
							)
						); ?>
						</div>
						
						<?php
				
					endwhile;
				else :
					?>
					<article class="no-results">
						
						<header class="entry-header">
							<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'ranking' ); ?></h1>
						</header>
					
						<div class="entry-content">
							<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'ranking' ); ?></p>
						</div>
					
					</article>
				<?php
				endif;
				?>
				<hr>
				<div class="comment-forms">
				 <?php comment_form(); ?>
				</div>
				<hr>
				<div class="comment-forms-all">
				<?php // If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
						//	comments_template();
						endif; ?>
					<?php comments_template(); ?>
				</div>
			</div>
	    </div>
		<div class="col-md-3">
		<?php get_sidebar(); // has_post_format() ?>
		</div>
	</div>
	</div>
</section>
<?php get_footer(); ?>