<div class="page-top-bar top-bar-06 onlydasktoptopheader">
	<div class="container-fluid">
		<div class="row row-eq-height">
			<div class="col-md-6">
				<div class="inner_top_bar">
                    <div class="header-left-widget"> 
                    <ul class="top-menu-left">
                    <li style="padding-left:0px"><a href="mailto:info@tridindia.com"><i class="fa fa-envelope"></i>info@tridindia.com</a></li>
                    <li><a href="tel:+91-0120-4257803"><i class="fa fa-phone"></i>+91-0120-4257803</a></li>
                    <li><a class="desktop-whatsapp" href="https://web.whatsapp.com/send?phone=918527599523&amp;text=Hi, I would like to know more about your translation services. Let's start chat now!" target="_blank" rel="noopener"><img class="alignnone1 size-full" src="https://www.tridindia.com/wp-content/uploads/2019/03/icon-whatsapp.png" alt="phone">+91-8527599523</a></li>
                    </ul>
                    </div> 
                    </div>
			</div>
			<div class="col-md-6">
				<div class="top-bar-wrap top-bar-right">
				    <div class="inner_top_bar pull-right">
					<ul class="top-menu-right">
					<li class="top-menu-hide"><a class="careers-menu" href="/services/translation/urgent-translation">
					<i class="fa fa-space-shuttle"></i> Urgent Translation</a></li>
					<li class="top-menu-hide"><a class="careers-menu" href="/careers"><i class="fa fa-user"></i> Careers</a></li>
					<li class="top-menu-hide"><a href="/translate-now"><i class="fa fa-handshake-o"></i> Translate Now</a></li>
					<li class="top-menu-hide"><a href="/blog"><i class="fa fa-rss"></i> Blog</a></li>
					</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="page-top-bar top-bar-06 onlymobiletopheader">
	<div class="container-fluid">
		<div class="row row-eq-height">
			<div class="col-md-12">
				<div class="top-bar-wrap top-bar-left">
					<div class="top_bar_inner">
				<div class="inner_top_bar">
				<div class="header-left-widget"> 
				<ul class="top-menu-left">
				<li><a href="mailto:info@tridindia.com"><i class="fa fa-envelope"></i>info@tridindia.com</a></li>
				<li><a class="desktop-whatsapp" href="whatsapp://send?text=Hi, I would like to know more about your translation services. Let's start chat now!&amp;phone=+918527599523" target="_blank" rel="noopener"><img class="alignnone1 size-full" src="https://www.tridindia.com/wp-content/uploads/2019/03/icon-whatsapp.png" alt="phone">+91-8527599523</a></li>
				<!-- <li><a href="whatsapp://send?text=Hello World!&phone=+918527599523">wh</a></li> -->
				</ul>
				</div>
				</div>
				</div> 
			</div>
		</div>
	</div>
</div>
</div>