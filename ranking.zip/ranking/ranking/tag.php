<?php get_header(); ?>
<section class="singlepage pb-5 pt-5">
	<div class="container">
	<div class="row">
		<div class="col-md-9">
			<div class="site-content">
				 <?php // echo $key_1_value = get_post_meta( get_the_ID(), 'origin', true ); ?>
				<?php
				$format = get_post_format() ? : 'standard';
				if ( have_posts() && $format) :
					while ( have_posts() ) :
						the_post();
						?>
						<article <?php post_class(); ?>>
						    <?php if(has_post_thumbnail()) { the_post_thumbnail( 'ranking-custom-image-size' ); } ?>
							<header class="entry-header">
								<?php the_title( '<h1 class="entry-title display-6">', '</h1>' ); ?>
							</header>
						
							<div class="entry-content">
								<?php   echo wp_trim_words( get_the_content(), 55, '...' ); // the_content(); ?>
								<div class="readmore mb-3">
									<a class="more-link" href="<?php echo esc_url(get_permalink()); ?>"> Read More</a>
								</div>
							</div>
						</article>
						
						<?php
				
					endwhile;
					?>
					<div class="text-center pt-4 pb-2">
						<?php
						 the_posts_pagination( array(
						    'prev_text' => __( 'Prev', 'ranking' ),
						    'next_text' => __( 'Next', 'ranking' ),
						) ); ?>
					</div>
					<?php
				else :
					?>
					<article class="no-results">
						
						<header class="entry-header">
							<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'ranking' ); ?></h1>
						</header>
					
						<div class="entry-content">
							<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'ranking' ); ?></p>
						</div>
					
					</article>
				<?php
				endif;
				?>
			</div>
	    </div>
		<div class="col-md-3">
		<?php get_sidebar(); // has_post_format() ?>
		</div>
	</div>
	</div>
</section>
<?php get_footer(); ?>